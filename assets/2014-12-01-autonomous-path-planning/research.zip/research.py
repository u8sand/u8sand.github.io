#!/bin/python

import numpy as np;

def unit_vector(v1, v2):
	""" This function computes the unit vector """
	dV = v1 - v2
	if np.allclose(dV, np.array([0., 0.])):
		return np.array([0., 0.])
	return dV/np.linalg.norm(dV)

def unit_vector_1d(v1, v2):
	""" This function computes the unit vector """
	dV = v1 - v2
	if np.allclose(dV, 0.):
		return 0.
	return dV/np.linalg.norm(dV)

class vehicle:
	P=np.array([0., 0.]) # global position
	F=[np.array([0., 1.]), 0.] # orientation velocity pair
	dF=[np.array([0., 0.]), 0.] # orientation', velocity' pair
	Rv=1.
	Rp=1.

	def __init__(self, L):
		self.F = L

	def update(self, t):
		""" Updates the position of the vehicle """
		self.F[0] += self.Rp * unit_vector(self.dF[0]*t, self.F[0])
		self.F[1] += self.Rv * unit_vector_1d(self.dF[1]*t, self.F[1])
		self.P += self.F[0] * self.F[1] * t

	def follow(self, L):
		""" Follows a leading function L, accepts only the next position-velocity pair L """
		self.dF = [unit_vector(L[0], self.F[0]), unit_vector_1d(L[1], self.F[1])]

	def getR(self, L):
		""" Obtains suitable R values for this step """
		dP = np.linalg.norm(L[0]-self.F[0])
		dV = np.linalg.norm(L[1]-self.F[1])
		self.Rp = 1/dP
		self.Rv = 1/dV

	def passed(self, L):
		""" This function checks to see if we've passed the current L """
		if L[0][0] <= self.P[0] and L[0][1] <= self.P[1]:
			return True
		return False

	def out(self, L):
		print('P: ', self.P)
		print('F: ',self.F)
		print('dF: ',self.dF)
		print('L: ',L)


# driving straight: from a stopped position, speed up and then slow down back to a stop.
path=[
	[np.array([0., 0.]), 0.],
	[np.array([0., 5.]), 5.],
	[np.array([0., 10.]), 0.]
]

# lane changing
path=[
	[np.array([0., 0.]), 0.],
	[np.array([0., 1.]), 0.],
	[np.array([2.5, 5.]), 5.],
	[np.array([2.5, 10.]), 0.]
]

# Street intersection
# right turn
path=[
	[np.array([0., 0.]), 0.],
	[np.array([0., 1.]), 1.],
	[np.array([2., 1.]), 1.]
]
# left turn
path=[
	[np.array([0., 0.]), 0.],
	[np.array([0., 1.5]), 1.],
	[np.array([-2., 2.]), 1.]
]

# 3-point turn
path=[
	[np.array([0., 0.]), 0.],
	[np.array([0., 1.]), 1.],
	[np.array([-2., 1.]), 0.],
	[np.array([-1., 2.]), -1.],
	[np.array([-1., 0.]), 1.]
]

# Obstacle avoidance
path=[
	[np.array([0., 0.]), 0.],
	[np.array([0., 5.]), 5.],
	[np.array([2., 6.]), 1.],
	[np.array([0., 5.]), 5.],
	[np.array([0., 10.]), 1.]
]

car=vehicle(path.pop(0))
car.getR(path[0])
car.out(None)
while path != []:
	input()
	next=path[0]
	car.follow(next)
	if car.passed(next):
		path.pop(0)
		car.getR(path[0])
	else:
		car.update(1.)
		car.out(next)

