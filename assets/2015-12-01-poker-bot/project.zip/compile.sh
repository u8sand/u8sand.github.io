#!/bin/bash

ghc -o python/haskell haskell/poker.hs
