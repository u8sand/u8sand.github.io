#!/bin/bash

cd python && python main.py
