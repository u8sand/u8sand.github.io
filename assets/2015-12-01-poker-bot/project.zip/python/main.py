#!/bin/python
# Daniel Clarke
# December 7, 2015
# CSCI6751 Final Project

# extra python dependencies (pip install to get)
#  matplotlib, pexpect

"""
This facilitates the game for the two players (of different programs).
"""

from game import Game
from player import Player

import matplotlib.pyplot as plt
players = [
  Player('./haskell'),
  # Player('nc -q -1 -l 9000'),
  Player('python ai.py'),]
g=Game(players)

N = 10
n = 0
s=[[] for p in range(len(players))]
y=[[] for p in range(len(players))]
t=[[] for p in range(len(players))]
while list(filter(lambda p: p.money == 0, g.players))==[] and n < N:
  scores = g.play()
  for i in range(len(g.players)):
    s[i].append((n, scores[i][0]))
    y[i].append((n, g.players[i].money))
    t[i].append((n, sum(g.players[i].time) / len(g.players[i].time)))
  n+=1

plt.subplot(3, 1, 1)
for a in s:
  plt.plot(*zip(*a))
plt.ylabel('hand value')
plt.ylim([-1,1000])
plt.subplot(3, 1, 2)
for a in y:
  plt.plot(*zip(*a))
plt.ylabel('money')
plt.ylim([0,200])
plt.subplot(3, 1, 3)
for a in t:
  plt.plot(*zip(*a))
plt.xlabel('game')
plt.ylabel('average time')
plt.ylim([0,1.5])
plt.show()