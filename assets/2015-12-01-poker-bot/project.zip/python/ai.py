# Daniel Clarke
# December 7, 2015
# CSCI6751 Final Project

import random
from copy import deepcopy
from player import Player
from deck import Deck

class AI:
  samples = 1000

  def __init__(self, players, me):
    self.players = players
    self.nplayers = len(self.players)
    self.me = me
    self.table = []

  def process(self):
    for n in range(5):
      self.processBets()
      self.processTable()

  def processBets(self):
    lastbet = -1
    current = 0
    pot = 0
    call = 0
    pcall = -1
    while pcall != current:
      p = self.players[current]
      if p.folded:
        current = (current + 1) % len(self.players)
        continue
      if p.me:
        bet = self.decideBet()
        print(bet)
      else:
        bet = int(input())
      if bet == -1: # fold
        p.folded = True
        self.nplayers -= 1
        if self.nplayers <= 1:
          break
      elif bet == 0: # call
        b = call - p.lastcall
        p.money -= b
        p.lastcall = call
        pot += b
        if pcall == -1:
          pcall = current
      else: # raise
        call += bet
        b = call - p.lastcall
        p.money -= b
        p.lastcall = call
        pot += b
        pcall = current
      current = (current + 1) % len(self.players)

  def processTable(self):
    self.table += input().split()

  def decideBet(self):
    n = 0
    for s in range(self.samples):
      g, d = self.fill()
      score = map(lambda p: (d.handValue(p.hand, g.table), p), g.players)
      if max(score, key=lambda p: p[0])[1].me:
        n += 1
    p = float(n)/self.samples
    e = p * self.me.money
    perRound = e / 5
    perBet = perRound / 3
    return max([-1,round(min([perRound - self.me.lastcall, perBet]))])

  def fill(self):
    g = deepcopy(self)
    d = Deck()
    d.deck.remove(g.me.hand[0])
    d.deck.remove(g.me.hand[1])
    while len(g.table) < 5:
      g.table.append(d.deck.pop())
    for p in g.players:
      if not p.me:
        p.hand = [d.deck.pop(), d.deck.pop()]
    return (g, d)

N = int(input())
players=[]
for n in range(N):
  p = Player('')
  p.id, p.money = map(int, input().split())
  players.append(p)
me, hand = input().split()
me=int(me)
players[me-1].hand = hand.split(',')
players[me-1].me = True

ai = AI(players, players[me-1])
ai.process()
