#!/bin/python
# Daniel Clarke
# December 7, 2015
# CSCI6751 Final Project

import pexpect

class Player:
  """
  Player parameters
  """
  money = 100
  hand = []
  lastcall = 0
  me = None
  folded = False

  def __init__(self, program):
    self.program = program
    self.process = None

  def start(self):
    self.hand = []
    self.folded = False
    self.time = []
    print('Starting player process ', self.program)
    self.process = pexpect.spawn(self.program, timeout=None)
    self.process.setecho(False)

  def kill(self):
    if self.process.isalive():
      print('Killing player process ', self.program)
      self.process.close()

  def send(self, message):
    if self.process.isalive():
      self.process.sendline(str(message))

  def recv(self):
    if self.process.isalive():
      out = self.process.readline().decode().strip()
      self.process.flush()
      return out
    return str()

  def __str__(self):
    return str("%d %s %d %s" % (self.id, self.program, self.money, self.hand))

  def __repr__(self):
    return str(self)
