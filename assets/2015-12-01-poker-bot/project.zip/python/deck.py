# Daniel Clarke
# December 7, 2015
# CSCI6751 Final Project

import random
import itertools

class Deck:
  """
  A Poker Deck
  """
  # value -> characters
  coats = {
    0: 'S',
    1: 'H',
    2: 'C',
    3: 'D',
  }
  cards = {
    11: 'J',
    12: 'Q',
    13: 'K',
    14: 'A',
  }
  cards_value = {v: k for k,v in cards.items()}
  number_of_cards = 2

  def __init__(self):
    # print('Creating new deck of cards')
    self.deck = ['%s%s' % (self.cards.get(card) or str(card), self.coats.get(coat) or str(coat)) for coat in range(0,3+1) for card in range(2,14+1)]
    # print('Shuffling deck')
    random.shuffle(self.deck)

  def deal(self):
    return [self.deck.pop() for c in range(self.number_of_cards)]

  def flip(self, r):
    print('Burn')
    self.deck.pop()
    print('Turn')
    return [self.deck.pop() for c in range(r)]

  def cardValue(self, c):
    v=c[:-1]
    return self.cards_value.get(v) or int(v)

  def cardCoat(self, c):
    return c[-1]

  def handValue(self, hand, table):
    # make a collective hand and split up numbers vs coats
    cards = sorted(table + hand, key=self.cardValue, reverse=True)
    straight = self.groupBy5(self.isStraight, map(lambda c: '%s%s' % (c[0], c[1]), list(set(map(lambda c: (self.cardValue(c), self.cardCoat(c)), self.dupAces(cards))))))
    multi = list(sorted(filter(lambda s: s[0]>1, map(lambda s: (len(s), s), self.groupBy(self.cardValue, cards))), reverse=True))
    flush = list(itertools.chain.from_iterable(map(lambda s: self.groupBy5(lambda c: True, s), self.groupBy(self.cardCoat, sorted(cards, key=self.cardCoat)))))
    straightFlush = list(filter(lambda s: s in flush, straight))
    # test for different possibilities
    if len(straightFlush)>0:
      return 900+self.cardValue(straightFlush[0][0])
    if len(multi)>0 and multi[0][0]==4:
      return 800+self.cardValue(multi[0][1][0])
    if len(multi)>1 and multi[0][0]==3 and multi[1][0] == 2:
      return 700+self.cardValue(multi[0][1][0])
    if len(flush)>0:
      return 600+self.cardValue(flush[0][0])
    if len(straight)>0:
      return 500+self.cardValue(straight[0][0])
    if len(multi)>0 and multi[0][0]==3:
      return 400+self.cardValue(multi[0][1][0])
    if len(multi)>0 and multi[0][0]==2:
      return 300+self.cardValue(multi[0][1][0])
    return self.cardValue(cards[0])

  def isStraight(self, cs):
    a = self.cardValue(cs[0])
    for b in map(self.cardValue, cs[1:]):
      if a-1 != b:
        return False
      a = b
    return True

  def isFlush(self, cs):
    a = cs[0][-1]
    for b in map(self.cardCoat, cs[1:]):
      if a != b:
        return False
      a = b
    return True

  def dupAces(self, cs):
    o = []
    for a in filter(lambda c: self.cardValue(c) == 14, cs):
      o.append('1%s' % (self.cardCoat(a)))
    return cs+o

  def groupBy(self, v, l):
    L=[]
    l=[(v(e), e) for e in l]
    sl=[l[0][1]]
    a=l[0]
    for b, c in l[1:]:
      if a == b:
        sl.append(c)
      else:
        L.append(sl)
        sl=[c]
        a=b
    L.append(sl)
    return L

  def groupBy5(self, c, l):
    L=[]
    l=list(l)
    while len(l)>=5:
      cs=l[:5]
      if c(cs):
        L.append(cs)
      l.pop(0)
    return L
