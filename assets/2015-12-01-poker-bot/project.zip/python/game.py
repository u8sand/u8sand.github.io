# Daniel Clarke
# December 7, 2015
# CSCI6751 Final Project

import time
from deck import Deck
from copy import copy

class Game:
  """
  Facilitates a poker game
  """
  def __init__(self, players):
    print('Creating new poker game')
    self.players = players
    self.safety = 1
    self.table = []

  def play(self):
    self.nplayers = len(self.players)

    print('Creating deck')
    self.deck = Deck()

    print('Start player processes...')
    for p in self.players:
      p.start()

    print('Take safety')
    pot = 0
    for p in self.players:
      p.money -= self.safety
      pot += self.safety

    print('Send initial information to players')
    i = 1
    for p in self.players:
      p.id = i
      # n Players
      p.send(len(self.players))
      # ID Money (n lines)
      ii = 1
      for pp in self.players:
        p.send('%d %d' % (ii, pp.money))
        ii += 1
      # ID Hand (yours)
      p.hand = self.deck.deal()
      print('Dealing cards', p)
      p.send('%d %s' % (i, ','.join(p.hand)))
      i += 1

    self.table = []

    print('Pre-Flop')
    pot += self.take_bets()
    if self.nplayers <= 1:
      return self.end_game(pot)

    for r in [3,1,1]: # Flop turn river
      turn = self.deck.flip(r) # Flip
      self.table += turn # Add to table
      print('Sending the turn to players')
      for p in self.players:
        p.send(' '.join(turn)) # Send the turn to players
      pot += self.take_bets()
      if self.nplayers <= 1: # See if we still have people playing
        return self.end_game(pot)

    return self.end_game(pot)

  def take_bets(self):
    print('Taking bets')
    lastbet = -1
    current = 0
    pot = 0
    call = 0
    pcall = -1
    while pcall != current:
      p = self.players[current]
      if p.folded:
        current = (current + 1) % len(self.players)
        continue
      print('Taking bet of', p.id)
      t = -time.perf_counter()
      bet = int(p.recv())
      t += time.perf_counter()
      print('time-spent', t)
      p.time.append(t)
      print('Player bet ', bet)
      if bet == -1: # fold
        print('Player folded, killing process.')
        p.kill()
        p.folded = True
        self.nplayers -= 1
        if self.nplayers <= 1:
          break
      elif bet == 0: # call
        print('Player called')
        b = call - p.lastcall
        p.money -= b
        p.lastcall = call
        pot += b
        if pcall == -1:
          pcall = current
      else: # raise
        print('Player raised')
        call += bet
        b = call - p.lastcall
        p.money -= b
        p.lastcall = call
        pot += b
        pcall = current
      print('Informing other players of bet')
      for pp in self.players:
        if pp != p:
          pp.send(str(bet))
      current = (current + 1) % len(self.players)
    return pot

  def end_game(self, pot):
    print('End game')
    scores = list(map(lambda p: (self.deck.handValue(self.table, p.hand), p), self.players))
    print(self.table, scores, sep='\n')
    winner = max(scores, key=lambda p: p[0] if not p[1].folded else -1)[1]
    self.players[winner.id-1].money += pot
    print('Killing player processes')
    for p in self.players:
      p.kill()
    return scores
