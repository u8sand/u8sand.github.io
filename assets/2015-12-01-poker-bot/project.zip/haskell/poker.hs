-- Daniel Clarke
-- December 7, 2015
-- CSCI6751 Final Project

-- extra haskell dependencies: (cabal install to get)
--  random-extras, split

import Control.Monad (replicateM, foldM)

import Data.Ord (comparing)
import Data.List (find, maximumBy, sortBy, groupBy, nub)
import Data.List.Split (splitOn)

import Data.Random
import Data.Random.Source.Std (StdRandom)
import Data.Random.Extras (choiceExtract)

import Data.Maybe (fromJust, isJust)

-- poker data type definitions
type ID         = Int
type Money      = Int
type Pot        = Money
type Card       = String
type Bet        = Money
type Hand       = [Card]
type Table      = [Card]

data Player     = Player ID Money Bet
                | Me ID Money Bet Hand
                | Folded ID
                deriving (Show, Eq)
data Game       = Game [Player] Table
                deriving (Show, Eq)


-- Decision engine
-- we're using a monte-carlo simulation:
--  play out $samples games assuming other players have random cards
--  and find the probability that we win
samples :: Int
samples = 1000

decideBet :: Player -> Game -> IO Bet
decideBet player@(Me _ m l h) game = do
  r <- monteCarlo player game samples
  let p = (fromIntegral r) / (fromIntegral samples)
      e = p * (fromIntegral m) -- expected return from our money
      perRound = e / 5         -- 5 rounds per game
      perBet = perRound / 3    -- bet expecting to have to raise up to 3x expectations
  return (maximum [-1, (round (minimum [perRound - (fromIntegral l), perBet]))])


-- interface functions

-- receive initial input and play the game
main :: IO ()
main = do
  numOfPlayers <- getLine
  players <- replicateM (read numOfPlayers :: Int) getLine
  me <- getLine
  playPoker (initializePoker players me) 0 (-1) 0

-- initialize the poker game object from the input strings
initializePoker :: [String] -> String -> Game
initializePoker players me = (Game (map (initializePlayer me) players) [])
  where
    initializePlayer :: String -> String -> Player
    initializePlayer me players
      | pid == myid = Me pid money 0 (splitOn "," cs)
      | otherwise = Player pid money 0
      where
        (pid:money:[]) = map read (splitOn " " players) :: [Int]
        (myids:cs:[]) = splitOn " " me
        myid = read myids :: Int

-- the round processing, process bets from everyone (including me)
-- note that this never ends, dealer should kill the processes.
playPoker :: Game -> ID -> ID -> Bet -> IO ()
playPoker game@(Game players table) current lastCall pot =
  let currentPlayer = players!!current
      next = (current + 1) `mod` (length players) in
    if isFolded currentPlayer
    then playPoker game next lastCall pot
    else if lastCall == current
      then do
        nTable <- getLine
        playPoker (Game players (table++(splitOn " " nTable))) 0 (-1) 0
      else if isMe currentPlayer
         then do
          bet <- decideBet currentPlayer (Game (filter (\p -> (not (isFolded p))) players) table)
          putStrLn (show bet)
          playPoker (updatePlayerMoney game current bet pot) next (updateLastCall bet lastCall current) (pot + (maximum [bet, 0]))
         else do
          bets <- getLine
          let bet = (read bets :: Int)
          playPoker (updatePlayerMoney game current bet pot) next (updateLastCall bet lastCall current) (pot + (maximum [bet, 0]))


-- util functions

-- modify player object after receiving a bet and before moving on
updatePlayerMoney :: Game -> ID -> Bet -> Bet -> Game
updatePlayerMoney (Game players table) current bet pot = Game nPlayers table
  where
    (fplayers, splayers) = splitAt current players
    mPlayer = updateMoney (head splayers) bet pot -- get the current player
    nPlayers = fplayers ++ (mPlayer : (tail splayers)) -- re-assemble the players with the new modified player
    -- update the money in the player object including money and last bet (so we know how much to add next time)
    updateMoney :: Player -> Bet -> Bet -> Player
    updateMoney p@(Player i m l) bet pot
      | bet > 0 = Player i (m - (bet + pot - l)) (bet + pot)
      | bet == 0 = Player i (m - (pot - l)) pot
      | otherwise = Folded i
    updateMoney me@(Me i m l h) bet pot
      | bet > 0 = Me i (m - (bet + pot - l)) (bet + pot) h
      | bet == 0 = Me i (m - (pot - l)) pot h
      | otherwise = Folded i

-- figure out if we're still betting or not
updateLastCall :: Bet -> ID -> ID -> ID
updateLastCall bet lastCall current
  | bet > 0 = current
  | bet == 0 && lastCall == -1 = current
  | otherwise = lastCall

-- what type of Player object
isMe :: Player -> Bool
isMe (Me _ _ _ _) = True
isMe _ = False

isFolded :: Player -> Bool
isFolded (Folded _) = True
isFolded _ = False

-- create a card from a tuple
cardFromTuple :: (Int, Char) -> Card
cardFromTuple (v, c)
  | v == 14 = 'A':[c]
  | v == 13 = 'K':[c]
  | v == 12 = 'Q':[c]
  | v == 11 = 'J':[c]
  | otherwise = (show v) ++ [c]

-- return the value/coat of a card
cardValue :: Card -> Int
cardValue card
  | v == "A" = 14
  | v == "K" = 13
  | v == "Q" = 12
  | v == "J" = 11
  | otherwise = (read v :: Int)
  where v = init card

cardCoat :: Card -> Char
cardCoat card = last card


-- MonteCarlo engine

-- monteCarlo simulation: evaluate the number of times we win in n games
monteCarlo :: Player -> Game -> Int -> IO Int
monteCarlo player game n = do
  results <- replicateM n (startSimulation game)
  return (length (filter (== player) results))
  where
    startSimulation :: Game -> IO Player
    startSimulation game = do
      game <- fillIn game
      return (simulate game)

-- simulate a single game and return the winner
simulate :: Game -> Player
simulate (Game players table) = snd (maximumBy (comparing fst) (map (scorePlayer table) players))

-- score a player, return his score and the player
scorePlayer :: Table -> Player -> (Int, Player)
scorePlayer table player@(Me i m l h) = ((scoreHand h table), player)

-- fill the game object with random cards (the unknowns)
fillIn :: Game -> IO Game
fillIn (Game players table) = do
  let me@(Me i m l h) = fromJust (find (isMe) players)
      usedCards = h++table
  (deck,nTable) <- fillInTable table (filter (`notElem` usedCards) createDeck)
  (deck,nPlayers) <- foldM fillInPlayer (deck,[]) players
  return (Game nPlayers nTable)
  where
    fillInPlayer :: ([Card],[Player]) -> Player -> IO ([Card], [Player])
    fillInPlayer (deck,nPlayers) (Player i m l) = do
      (deck,c1) <- runRVar (fromJust (choiceExtract deck)) StdRandom
      (deck,c2) <- runRVar (fromJust (choiceExtract deck)) StdRandom
      return (deck, (Me i m l [c1,c2]):nPlayers)
    fillInPlayer (deck,nPlayers) me@(Me _ _ _ _) =
      return (deck, me:nPlayers)

    fillInTable :: Table -> [Card] -> IO ([Card], Table)
    fillInTable table deck
      | (length table) < 5 = do
        (nDeck,nCard) <- runRVar (fromJust (choiceExtract deck)) StdRandom
        (nDeck,nTable) <- fillInTable (nCard:table) nDeck
        return (nDeck,nTable)
      | otherwise = return (deck, table)


-- Gameplay

-- create a full playingCard deck
createDeck :: [Card]
createDeck = [cardFromTuple (x,y) | x <- [2..14], y <- ['S','H','C','D']]

-- handle aces (they might be 14s or 1s)
dupAces :: [Card] -> [Card]
dupAces cards = cards ++ ones
  where
    aces = filter (\c -> (cardValue c) == 14) cards
    ones = map (\c -> cardFromTuple (1, cardCoat c)) aces

-- score our hand
scoreHand :: Hand -> Table -> Int
scoreHand hand table
  | isJust straightFlush = 900 + (kick (fromJust straightFlush))
  | isJust fourOfKind = 800 + (kick (fromJust fourOfKind))
  | (isJust threeOfKind) && (isJust twoOfKind) = 700 + (kick (fromJust threeOfKind))
  | flush /= [] = 600 + (kick (head flush))
  | straight /= [] = 500 + (kick (head straight))
  | isJust threeOfKind = 400 + (kick (fromJust threeOfKind))
  | isJust twoOfKind = 300 + (kick (fromJust twoOfKind))
  | otherwise = kick hand
  where
    cs = sortBy (flip (comparing cardValue)) (hand ++ table)
    multi = multiSet cs
    flush = flushSet cs
    straight = straightSet (dupAces cs)
    straightFlush = find (isFlush) straight
    fourOfKind = find (\a -> length a == 4) multi
    threeOfKind = find (\a -> length a == 3) multi
    twoOfKind = find (\a -> length a == 2) multi

-- form different hand combinations
straightSet :: [Card] -> [[Card]]
straightSet cards = groupBy5 (isStraight) (map (snd) (nub (map (\c -> (cardValue c, c)) cards)))

multiSet :: [Card] -> [[Card]]
multiSet cards = sortBy (flip compare) (filter (\s -> (length s) > 1) (groupBy (\x y -> (cardValue x) == (cardValue y)) cards))

flushSet :: [Card] -> [[Card]]
flushSet cards = concat (map (groupBy5 (\c -> True)) (groupBy (\x y -> (cardCoat x) == (cardCoat y)) (sortBy (comparing cardCoat) cards)))

-- check if hands satisfy requirements for straight/flush
isStraight :: [Card] -> Bool
isStraight cards = isStraight_ (map (cardValue) cards)
  where
    isStraight_ :: [Int] -> Bool
    isStraight_ (a:b:rest) = ((a-1) == b) && (isStraight_ (b:rest))
    isStraight_ (a:[]) = True

isFlush :: [Card] -> Bool
isFlush cards = isFlush_ (map (cardCoat) cards)
  where
    isFlush_ :: [Char] -> Bool
    isFlush_ (a:b:rest) = (a == b) && (isFlush_ (b:rest))
    isFlush_ (a:[]) = True

-- make permutations of 5 cards (assuming sorted list)
groupBy5 :: ([Card] -> Bool) -> [Card] -> [[Card]]
groupBy5 cond straight 
  | (length straight) >= 5 = if (cond cards) then (cards : rest) else rest
  | otherwise = []
  where
    cards = take 5 straight
    rest = groupBy5 cond (tail straight)

-- determine kicker (highest card)
kick :: [Card] -> Int
kick cs = maximum (map (cardValue) cs)
