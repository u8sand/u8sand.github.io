# Daniel Clarke
## May 11, 2016
### CSCI6617 Game Programming Final Project

This game is a multiplayer free for all sword fighting game. While very much a prototype, the game is 3D, has a novel control keyboard control system, and networking support.

#### TODO

- Mesh collision detection for ground
- Networking


### NOTE

`plugins.cfg` and `resources.cfg` should be copied into the build directory before excecuting the game.