#ifndef UTIL_H
#define UTIL_H

void  random_init();
float random_float();
float random_range(float start, float end);

#endif // UTIL_H
