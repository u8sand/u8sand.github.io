#include "Game.h"

#include <OGRE/OgreEntity.h>
#include <OGRE/OgreSceneNode.h>

Game::Game():
  OgreApplication("Game"),
  network(0), world(0), player(0) {
  // network = new Network();
}

Game::~Game() {
  if(network)
    delete network;
}

bool Game::frameRenderingQueued(const Ogre::FrameEvent &evt) {
  return OgreApplication::frameRenderingQueued(evt) &&
         world->Process()/* && network->Process()*/;
}

void Game::createScene() {
  mSceneMgr->setAmbientLight(Ogre::ColourValue(1, 1, 1));
  world = new World(mSceneMgr->getRootSceneNode()->createChildSceneNode(Ogre::Vector3(0,0,0)));
  player = new PlayerOne(world);
  player->attachCamera(mCamera);
}
