#ifndef NETWORK_H
#define NETWORK_H

#include "SocketAddr.h"
#include "Player.h"
#include <unordered_map>
#include <memory>

class Network : public std::unordered_map< SocketAddr, std::shared_ptr<Player> > {
public:
  Network();
  /*virtual */~Network();

  /*virtual */bool Process();

protected:
  const ushort port = 55555;
  SOCKET sock;
  SocketAddr addr;
};

#endif // NETWORK_H
