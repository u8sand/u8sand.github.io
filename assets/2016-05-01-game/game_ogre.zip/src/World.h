#ifndef WORLD_H
#define WORLD_H

#include "Object.h"

#include <deque>

typedef std::deque<Object*> Objects;

class World : public Object {
public:
  World(Ogre::SceneNode *node);

  virtual bool Process();

  virtual void addChild(Object *obj);

protected:
  Objects objects;
};

#endif // WORLD_H
