#include "Util.h"

#include <cstdlib>
#include <ctime>

void random_init() {
  srand(time(0));
}

float random_float() {
  // http://stackoverflow.com/questions/686353/c-random-float-number-generation
  return static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
}

float random_range(float start, float end) {
  return (random_float() * (end - start)) + start;
}
