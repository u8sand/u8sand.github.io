#include "Object.h"

Object::Object(Object *parent) {
  if(parent)
    parent->addChild(this);
  else
    node_ = 0;
}

Object::Object(Ogre::SceneNode *node) {
  node_ = node;
}

Object::~Object() {}

bool Object::Process() {
  return true;
}

void Object::addChild(Object *obj) {
  assert(node_);
  obj->node_ = node_->createChildSceneNode();
}

Object *Object::createChild() {
  return new Object(this);
}

Ogre::SceneNode *Object::node() {
  return node_;
}
