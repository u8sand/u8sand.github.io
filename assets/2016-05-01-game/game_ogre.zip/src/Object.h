#ifndef OBJECT_H
#define OBJECT_H

#include <OGRE/OgreSceneNode.h>

class Object {
public:
  Object(Object *parent = 0);
  Object(Ogre::SceneNode *node);
  virtual ~Object();

  virtual bool Process();

  virtual void addChild(Object *obj);
  virtual Object *createChild();

  Ogre::SceneNode *node();
protected:
  Ogre::SceneNode *node_;
};

#endif // OBJECT_H
