#include "World.h"

#include "Player.h"

#include <OGRE/OgreSceneManager.h>
#include <OGRE/OgreEntity.h>


World::World(Ogre::SceneNode *node):
  Object(node) {
  Ogre::Entity *dojo = node->getCreator()->createEntity("ogrehead.mesh");
  node->attachObject(dojo);
}

bool World::Process() {
  for(Objects::iterator object = objects.begin(); object != objects.end(); object++) {
    if(!(*object)->Process()) {
      ; // TODO: kill player
    }
  }
  // TODO: Handle Collisions
  return true;
}

void World::addChild(Object *obj) {
  Object::addChild(obj);
  objects.push_back(obj);
}

//
// static inline float limit_to(float x, float min_x, float max_x) {
//   if(x < min_x) return min_x;
//
//   if(x > max_x) return max_x;
//
//   return x;
// }
//
// static inline bool equal_to(float a, float b, float eps) {
//   float d = abs(a) - abs(b);
//
//   return (d < eps) && (d > -eps);
// }
//
// D3DXVECTOR3 Game::wall_pos(D3DXVECTOR3 pos, D3DXVECTOR3 dir) {
//   BOOL  hit;
//   DWORD face, count;
//   FLOAT pU, pV, dist;
//   LPD3DXBUFFER allHits;
//
//   // Wall/Object Collision
//   D3DXIntersect(mapModel->mesh,
//                 &pos, &dir, &hit, &face,
//                 &pU, &pV, &dist, &allHits,
//                 &count);
//
//   if(hit) {
//     D3DXINTERSECTINFO *hits =
//       reinterpret_cast<D3DXINTERSECTINFO *>(allHits->GetBufferPointer());
//
//     for(int i = 0; i < count; i++) {
//       if(hits[i].FaceIndex == face) {
//         dist = hits[i].Dist;
//         break;
//       }
//     }
//     return pos + dist * dir;
//   }
//   else    return D3DXVECTOR3();
// }
//
// int Game::ProcessCollisions(Player *player) {
//   static const float floor_thickness = 1.0f,
//                      wall_thickness  = 1.5f,
//                      map_death       = -5.0f,
//                      backoff         = 0.1f;
//
//
//   // Mesh Dojo Collision Handling
//   // Drawing a line from the player position downwards and in the direction
//   //  we're moving, what is the first face on the dojo that we hit?
//   D3DXVECTOR3 down = { 0.0f, -1.0f, 0.0f },
//               dir  = player->last_pos - player->pos,
//               ndir, nxdir, nzdir, wall;
//
//   D3DXVec3Normalize(&ndir, &dir);
//   nxdir = { ndir.x, 0.0f, 0.0f };
//   nzdir = { 0.0f, 0.0f, ndir.z };
//
//   if(player->last_pos != player->pos) {
//     player->pos.x = limit_to(player->pos.x,
//                              mapDimensions.first.x + wall_thickness,
//                              mapDimensions.second.x - wall_thickness);
//     player->pos.z = limit_to(player->pos.z,
//                              mapDimensions.first.z + wall_thickness,
//                              mapDimensions.second.z - wall_thickness);
//
//     /*wall = wall_pos(player->last_pos, nxdir);
//        if (wall != D3DXVECTOR3()) {
//             if (ndir.x > 0 && player->pos.x > wall.x)
//                     player->pos.x = wall.x;
//             else if (ndir.x < 0 && player->pos.x < wall.x)
//                     player->pos.x = wall.x;
//        }
//        wall = wall_pos(player->last_pos, nzdir);
//        if (wall != D3DXVECTOR3()) {
//             if (ndir.z > 0 && player->pos.z > wall.z)
//                     player->pos.z = wall.z;
//             else if (ndir.z < 0 && player->pos.z < wall.z)
//                     player->pos.z = wall.z;
//        }*/
//   }
//
//   // Gravity/ground collision
//
//   player->last_pos.y += floor_thickness;
//   float next_y      = player->pos.y + player->yvel;
//   D3DXVECTOR3 floor = wall_pos(player->last_pos, down);
//
//   if((floor == D3DXVECTOR3()) || (next_y > floor.y)) {
//     player->yvel -= gravity;
//
//     if(next_y < map_death) {
//       KillPlayer(player);
//       return 0;
//     }
//   }
//   else {
//     next_y       = floor.y;
//     player->yvel = 0;
//   }
//
//   player->pos.y = next_y;
//
//
//   // Player collision
//
//   if(players.front() != players.back()) {
//     static MODEL playerModel, playerSword, p2Sword;
//     static D3DXMATRIX playerMatrix, p2Matrix;
//
//     playerModel.mesh = SkinModelMesh(player->model);
//     playerSword.mesh = SkinModelMesh(player->sword);
//
//     Translate(playerMatrix, player->pos, player->dir);
//
//     for(Players::iterator p = players.begin();
//         p != players.end();
//         p++) {
//       if((*p) == player) continue;
//       Translate(p2Matrix, (*p)->pos, (*p)->dir);
//       p2Sword.mesh = SkinModelMesh((*p)->sword);
//
//       if(Collided(&playerModel, playerMatrix, &p2Sword, p2Matrix)) {
//         if(CollidedSkinModel((*p)->model, p2Matrix, &playerSword, playerMatrix)) {
//           if(Collided(&playerSword, playerMatrix, &p2Sword, p2Matrix)) {
//             (*p)->pos   -= TranslateRot((*p)->dir) * backoff;
//             player->pos -= TranslateRot(player->dir) * backoff;
//           }
//           else {
//             KillPlayer((*p));
//             KillPlayer(player);
//           }
//         }
//         else KillPlayer(player);
//       }
//       else if(CollidedSkinModel((*p)->model, p2Matrix, &playerSword,
//                                 playerMatrix)) {
//         if(Collided(&playerSword, playerMatrix, &p2Sword, p2Matrix)) {
//           (*p)->pos   -= TranslateRot((*p)->dir) * backoff;
//           player->pos -= TranslateRot(player->dir) * backoff;
//         }
//         else KillPlayer((*p));
//       }
//       p2Sword.mesh->Release();
//     }
//     playerModel.mesh->Release();
//     playerSword.mesh->Release();
//   }
//
//   return 0;
// }
