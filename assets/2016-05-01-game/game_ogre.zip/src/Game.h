// Modified from OGRE Tutorial's TutorialApplication

#ifndef GAME_H
#define GAME_H

#include "OgreApplication.h"
#include "PlayerOne.h"
#include "World.h"
#include "Network.h"

class Game: public OgreApplication
{
public:
  Game();
  /*virtual */~Game();

protected:
  /*virtual */void createScene();
  /*virtual */bool frameRenderingQueued(const Ogre::FrameEvent &evt);

  Network *network;
  World *world;
  PlayerOne *player;
};

#endif // GAME_H
