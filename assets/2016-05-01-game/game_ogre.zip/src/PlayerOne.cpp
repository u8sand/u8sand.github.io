#include "PlayerOne.h"

#include <OIS/OIS.h>

PlayerOne::PlayerOne(Object *parent):
  Player(parent) {}

bool PlayerOne::Process() {
  static const float rot_speed  = 0.1f,
                     jmp_vel    = 1.5f,
                     run_speed  = 0.4f,
                     walk_speed = 0.1f;
  static const time_t timeout   = 10;
  static time_t tick, tock;
  static int    stage;

  static const int nkeys       = 11;
  static const int keys[nkeys] = {
    OIS::KC_Q,
    OIS::KC_W,
    OIS::KC_E,
    OIS::KC_A,
    OIS::KC_S,
    OIS::KC_D,
    OIS::KC_UP,
    OIS::KC_DOWN,
    OIS::KC_LEFT,
    OIS::KC_RIGHT,
    OIS::KC_SPACE
  };

  char pressed = false;
  static char time[nkeys];

  // last_pos = pos;

  // Input handling
  // app->DirectInput_Update();
  //
  // for(int i = 0; i < nkeys; i++) {
  //   char keyState = app->Key_Down(keys[i]);
  //
  //   if(keyState) {
  //     pressed = true;
  //
  //     if(!time[i]) time[i] = timeout;
  //     else if(time[i] < timeout) time[i] = 2 * timeout;
  //   }
  //   else if(time[i] > 0) {
  //     if(--time[i] == timeout) time[i] = 0;
  //   }
  // }
  //
  // if(pressed) {
  //   if(time[6] && (time[6] % timeout == 0)) { // UP
  //     if((playerState != RUNNING) &&
  //        (time[6] > timeout)) setPlayerState(RUNNING,
  //                                      !(playerState == RESTING ||
  //                                        playerState == WALKING));
  //
  //     if(playerState == RUNNING) pos = pos + app->TranslateRot(dir) * run_speed;
  //     else if((playerState != WALKING) && time[6]) setPlayerState(WALKING,
  //                                                           playerState !=
  //                                                           RESTING);
  //
  //     if(playerState == WALKING) pos = pos + app->TranslateRot(dir) * walk_speed;
  //   }
  //
  //   if(time[7] && (time[7] % timeout == 0)) { // DOWN
  //     if((playerState != RUNNING) &&
  //        (time[7] > timeout)) setPlayerState(RUNNING,
  //                                      !(playerState == RESTING ||
  //                                        playerState == WALKING));
  //
  //     if(playerState == RUNNING) pos = pos - app->TranslateRot(dir) * run_speed;
  //     else if((playerState != WALKING) && time[7]) setPlayerState(WALKING,
  //                                                           playerState !=
  //                                                           RESTING);
  //
  //     if(playerState == WALKING) pos = pos - app->TranslateRot(dir) * walk_speed;
  //   }
  //
  //   if(time[8] && (time[8] % timeout == 0)) // LEFT
  //     dir.y -= rot_speed;
  //
  //
  //   if(time[9] && (time[9] % timeout == 0)) // RIGHT
  //     dir.y += rot_speed;
  //
  //   if(time[1] && time[4]) {
  //     if(time[1] < time[4]) // ws
  //       setPlayerState(SLICE_UP_DOWN);
  //     else                  // sw
  //       setPlayerState(SLICE_DOWN_UP);
  //   }
  //
  //   if(time[3] && time[5]) {
  //     if(time[3] < time[5]) // ad
  //       setPlayerState(SLICE_LEFT_RIGHT);
  //     else                  // da
  //       setPlayerState(SLICE_RIGHT_LEFT);
  //   }
  //
  //   if(time[0] && time[2])                                      // qe
  //     setPlayerState(SLICE_UNSHEATH);
  //
  //   if(time[10] && (time[10] % timeout == 0) && (yvel == 0.0f)) // SPACE
  //     yvel = jmp_vel;
  // }
  // else {
  //   if(time[6] || time[7]) setPlayerState(RESTING);
  //
  //   if((time[6] > timeout) || (time[7] > timeout)) time[6] = time[7] = 0;
  // }

  // Update camera
  // static D3DXVECTOR3 camera_pos;
  //
  // camera_pos = pos - app->TranslateRot(dir) * 12;
  //
  // app->SetCamera(camera_pos.x,
  //                camera_pos.y + 6,
  //                camera_pos.z,
  //                pos.x,
  //                pos.y,
  //                pos.z);

  return Player::Process();
}

void PlayerOne::attachCamera(Ogre::Camera *mCamera) {
  this->mCamera = mCamera;
  node()->attachObject(mCamera);
}
