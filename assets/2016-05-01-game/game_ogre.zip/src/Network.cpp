#include "Network.h"

#include "Player.h"

#ifdef OS_WINDOWS
static WSADATA wsa;
#endif

Network::Network() {
  #ifdef OS_WINDOWS
  WSAStartup(MAKEWORD(2, 2), &wsa);
  #endif

  sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if(sock == INVALID_SOCKET) throw INVALID_SOCKET;

  #ifdef OS_WINDOWS
    u_long nb = 1; ioctlsocket(sock, FIONBIO, &nb);
  #else
    // TODO: set not blocking
  #endif

  addr = SocketAddr(AF_INET, INADDR_ANY, port);
  bind(sock, reinterpret_cast<struct sockaddr *>(&addr), sizeof(addr));
}

Network::~Network() {
  #ifdef OS_WINDOWS
    closesocket(sock);
    WSACleanup();
  #else
    close(sock);
  #endif
}

bool Network::Process() {
  // Send network packets
  char *data;
  uint   size;
  register int ret;

  for(Network::iterator peer = begin(); peer != end(); peer++) {
    ret = sendto(sock, data, size, 0, reinterpret_cast<struct sockaddr *>(&addr), sizeof(addr));
    if(ret == SOCKET_ERROR); // TODO: deal with error
  }

  // Receive network packets
  Network::iterator peer;
  SocketAddr peer_addr;
  uint peer_addr_len;

  ret = recvfrom(sock, data, size, 0, reinterpret_cast<struct sockaddr *>(&peer_addr), &peer_addr_len);
  while(ret != SOCKET_ERROR && ret != 0) {
    peer = find(peer_addr);
    if(peer != end())
      peer->second->setPlayerData(data);
    else {
      // TODO: unknown address, check with server
    }
    ret = recvfrom(sock, data, size, 0, reinterpret_cast<struct sockaddr *>(&peer_addr), &peer_addr_len);
  }
  return true;
}
