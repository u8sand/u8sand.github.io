#include "SocketAddr.h"

SocketAddr::SocketAddr() {
  memset(this, 0, sizeof(*this));
}

SocketAddr::SocketAddr(int family, int addr, int port) {
  memset(this, 0, sizeof(*this));
  sin_family      = AF_INET;
  sin_addr.s_addr = addr;
  sin_port        = htons(port);
}

SocketAddr::SocketAddr(const SocketAddr &addr) {
  memcpy(this, &addr, sizeof(addr));
}

SocketAddr::~SocketAddr() {}

SocketAddr &SocketAddr::operator=(const SocketAddr &addr) {
  memcpy(this, &addr, sizeof(addr));
  return *this;
}

bool SocketAddr::operator==(const SocketAddr &addr) const {
  return sin_family == addr.sin_family &&
         sin_port == addr.sin_port &&
         #ifdef OS_WINDOWS
           sin_addr.S_un.S_addr == addr.sin_addr.S_un.S_addr &&
         #else
           sin_addr.s_addr == addr.sin_addr.s_addr &&
         #endif
         memcmp(sin_zero, addr.sin_zero, 8) == 0;
}

bool SocketAddr::operator!=(const SocketAddr &addr) const {
  return !(*this == addr);
}
