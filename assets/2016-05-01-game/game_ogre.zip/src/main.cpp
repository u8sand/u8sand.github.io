#include "Game.h"

#ifdef OS_WINDOWS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <iostream>
#endif

#ifdef __cplusplus
extern "C" {
#endif
  #ifdef OS_WINDOWS
    INT WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR strCmdLine, INT) {
  #else
    int main(int argc, char * argv[]) {
  #endif
    Game game;
    try {
      game.exec();
    } catch(Ogre::Exception &e) {
      #if OS_WINDOWS
        MessageBox(NULL,
          e.getFullDescription().c_str(),
          "An exception has occured!",
          MB_OK | MB_ICONERROR | MB_TASKMODAL);
      #else
        std::cerr << "An exception has occured: " <<
          e.getFullDescription().c_str() << std::endl;
      #endif
    }
    return 0;
  }
#ifdef __cplusplus
}
#endif
