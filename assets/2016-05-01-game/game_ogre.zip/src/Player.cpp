#include "Player.h"

#include <OGRE/OgreSceneManager.h>
#include <OGRE/OgreEntity.h>

Player::Player(Object *parent):
  Object(parent),
  yvel(0),
  state(DEFAULT) {
  Ogre::Entity *model = node()->getCreator()->createEntity("Character", "character.mesh");
  node()->attachObject(model);
  setPlayerState(RESTING);

  // #include "Util.h"
  // setPosition(Ogre::Vector3(
  //   random_range(dim.first.x, dim.second.x / 2),
  //   random_range(dim.first.y, dim.second.y),
  //   random_range(dim.first.z, dim.second.z / 2)
  // ));
  // dir = random_range(0, 2*Ogre::PI);
}

bool Player::Process() {
  static const float anim_duration = 1.75f,
                     anim_speed    = 0.05f;

  // If animation is done, process stateQueue
  //   if(!stateQueue.empty()) {
  //     playerState = stateQueue.front();
  //     stateQueue.pop_front();
  //     app->SetAnimationTrack(model, playerState);
  //     app->SetAnimationTrack(sword, playerState);
  //   }
  //   else if((playerState != DEFAULT) &&
  //           (playerState != RESTING) &&
  //           (playerState != RUNNING) &&
  //           (playerState != WALKING)) SetState(RESTING);

  // Draw player
  // app->DoTranslate();
  // app->DoTranslate(pos, D3DXVECTOR3 { dir.x, dir.y + D3DX_PI / 2, dir.z });
  // app->DrawSkinModel(model);
  //
  // app->DoTranslate();
  // app->DoTranslate(pos, D3DXVECTOR3 { dir.x, dir.y + D3DX_PI / 2, dir.z });
  // app->DrawSkinModel(sword);
  // if dead return false
  return true;
}

int Player::playerDataSize() const {
  return sizeof(this);
}

const char *Player::playerData() const {
  // return reinterpret_cast<const char*>(this);
}

void Player::setPlayerData(const char *playerData) {
  // const Player *p = reinterpret_cast<const Player*>(playerData);
  // setPosition(p->pos);
  // dir = p->dir;
  // yvel = p->yvel;
  // state = p->state;
}

void Player::setPlayerState(PlayerState state, bool queue) {
  if(queue) {
    if(stateQueue.empty() ||
       (stateQueue.back() != state)) stateQueue.emplace_back(state);
  }
  else {
    stateQueue.clear();
    this->state = state;

    // Set Animation
    // app->SetAnimationTrack(model, state);
    // app->SetAnimationTrack(sword, state);
  }
}
