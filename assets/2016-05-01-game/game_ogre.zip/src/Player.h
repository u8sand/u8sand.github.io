#ifndef PLAYER_H
#define PLAYER_H

#include "Object.h"

#include <deque>

enum PlayerState {
  DEFAULT,          // Default_Action
  WALKING,          // walking_2_6mps
  SLICE_UP_DOWN,    // slice_updown
  SLICE_UNSHEATH,   // slice_unsheath
  SLICE_RIGHT_LEFT, // slice_rightleft
  SLICE_LEFT_RIGHT, // slice_leftright
  SLICE_DOWN_UP,    // slice_downup
  SHEATHING,        // sheathing
  RUNNING,          // running_8mps
  RESTING,          // resting
  UNSHEATHING       // unsheathing
};

typedef std::deque<PlayerState> PlayerStateQueue;

class Player : public Object {
public:
  Player(Object *parent);

  virtual bool Process();

  virtual int playerDataSize() const;
  virtual const char *playerData() const;
  virtual void setPlayerData(const char *playerData);

  PlayerState playerState() const;

protected:
  void setPlayerState(PlayerState state, bool queue = false);

  double  yvel;
  PlayerState state;
  PlayerStateQueue stateQueue;
};


#endif // PLAYER_H
