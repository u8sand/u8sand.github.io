#ifndef SOCKET_ADDR_H
#define SOCKET_ADDR_H

#ifdef OS_WINDOWS
#include <windows.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h> // socket
#include <netinet/in.h> // sockaddr_in
#include <unistd.h>     // close
#define SOCKET int
#define SOCKET_ERROR -1
#define INVALID_SOCKET -1
#endif

#include <functional>
#include <cstring>

class SocketAddr: public sockaddr_in {
public:
  SocketAddr();
  SocketAddr(int family, int addr, int port);
  SocketAddr(const SocketAddr &addr);
  ~SocketAddr();

  SocketAddr &operator=(const SocketAddr &addr);

  bool operator==(const SocketAddr &addr) const;
  bool operator!=(const SocketAddr &addr) const;
};

namespace std {
  template < class T >
  inline void hash_combine(size_t &seed, const T &v)
  {
    hash < T > hasher;

    seed ^= hasher(v) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
  }

  template < >
  struct hash < SocketAddr >
  {
    size_t operator()(const SocketAddr &addr) const
    {
      size_t seed = 0;

      hash_combine(seed, addr.sin_family);
      hash_combine(seed, addr.sin_port);

      #ifdef OS_WINDOWS
        hash_combine(seed, addr.sin_addr.S_un.S_addr);
      #else
        hash_combine(seed, addr.sin_addr.s_addr);
      #endif

      for(int i = 0; i < 8; i++) hash_combine(seed, addr.sin_zero[i]);

      return seed;
    }
  };
}

#endif // SOCKET_ADDR_H
