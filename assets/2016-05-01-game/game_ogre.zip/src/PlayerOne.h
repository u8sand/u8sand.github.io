#ifndef PLAYER_ONE_H_
#define PLAYER_ONE_H

#include "Object.h"
#include "Player.h"

#include <OGRE/OgreCamera.h>

class PlayerOne : public Player {
public:
  PlayerOne(Object *parent);

  virtual bool Process();
  virtual void attachCamera(Ogre::Camera *mCamera);
protected:
  Ogre::Camera *mCamera;
};

#endif // PLAYER_ONE_H
