#!/bin/python

import re
import sys

f_re = re.compile(r'"([^(\.|/)]+\.\w{1,4})"')
for f in sys.argv[1:]:
    fr = open(f, 'r'); out = f_re.sub(r'"rcs/textures/\1"',  ''.join(fr.readlines())); fr.close()
    fw = open(f, 'w'); print(out, end='', file=fw); fw.close()
