#include "NetworkManager.h"
#include "Game.h"
#include "Player.h"
#include "PlayerOne.h"

#include <winsock.h>
#include <iostream>

static WSADATA wsa;

NetworkManager::NetworkManager(Game *game) :
  game(game) {
  WSAStartup(MAKEWORD(2, 2), &wsa);
}

NetworkManager::~NetworkManager() {
  WSACleanup();
}

int NetworkManager::Init() {
  const int port = 43514;

  sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

  if(sock == INVALID_SOCKET) return -1;

  // enable broadcast packets
  char b = 1; setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &b, sizeof(b));

  // set to non-blocking
  u_long nb = 1; ioctlsocket(sock, FIONBIO, &nb);

  // prepare local address
  addr = SocketAddr(AF_INET, INADDR_ANY, port);

  // prepare broadcast
  broadcast = SocketAddr(AF_INET, BROADCAST, port);

  // bind socket
  bind(sock, (struct sockaddr *)&addr, sizeof(addr));

  return 0;
}

int NetworkManager::Run() {
  static const time_t timeout = 120;
  char *data;
  int   size;

  SocketAddr peer_addr;
  int addr_len = sizeof(peer_addr);
  int recv_len;

  PeerMap::iterator peer;
  Player *peer_player = NULL;

  static time_t tock;
  time_t tick;

  tick = GetTickCount();

  if(tick - tock < timeout) return 0;

  size = sizeof(struct sockaddr);
  data = new char[size];

  while (tick - tock < timeout) {
	  recv_len =
		  recvfrom(sock, data, size, 0, (struct sockaddr *)&peer_addr, &addr_len);

	  if (recv_len == SOCKET_ERROR) return 1; // sock closed
	  else if (recv_len == 0) break;      // no incoming data
	  else if (recv_len == size) {
		  int pid = *reinterpret_cast<int *>(data);
		  peer = peers.find(pid);

		  if (peer != peers.end()) peer_player = peer->second;
		  else if (pid != game->player->PID()) peer_player = game->NewPlayer(pid);
		  else    peer_player = 0;

		  if (peer_player) {
			  peers[pid] = peer_player;
			  peer_player->SetData(data, recv_len);

			  if (peer_player->IsDead()) peers.erase(peers.find(pid));
		  }
	  }
  }

  delete[] data;

  tick = GetTickCount();

  if(tick - tock < timeout) return 0;

  // send our position to peers
  data = game->player->GetData(size); // points data to playerdata and sets size

  recv_len =
    sendto(sock, data, size, 0, (struct sockaddr *)&broadcast, sizeof(broadcast));

  if(recv_len == SOCKET_ERROR) return 1;

  delete[] data;

  tock = tick;

  return 0;
}

int NetworkManager::End() {
  closesocket(sock);
  return 0;
}
