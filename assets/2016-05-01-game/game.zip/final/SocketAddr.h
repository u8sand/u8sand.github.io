#pragma once

#include <windows.h>
#include <functional>
#include <string.h>

#pragma comment(lib, "ws2_32.lib")

class SocketAddr: public sockaddr_in {
public:

  SocketAddr() {
    memset(this, NULL, sizeof(*this));
  }
  SocketAddr(int family, int addr, int port) {
    memset(this, NULL, sizeof(*this));
    sin_family      = AF_INET;
    sin_addr.s_addr = addr;
    sin_port        = htons(port);
  }
  SocketAddr(const SocketAddr &addr) {
    memcpy(this, &addr, sizeof(addr));
  }
  SocketAddr& operator = (const SocketAddr &addr) {
    memcpy(this, &addr, sizeof(addr));
    return *this;
  }
  bool operator == (const SocketAddr &addr) const {
    return sin_family == addr.sin_family &&
           sin_port == addr.sin_port &&
           sin_addr.S_un.S_addr == addr.sin_addr.S_un.S_addr &&
           strncmp(sin_zero, addr.sin_zero, 8) == 0;
  }
  bool operator != (const SocketAddr &addr) const {
    return !(*this == addr);
  }
};
