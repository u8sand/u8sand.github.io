#include "DirectXApplication.h"

void DirectXApplication::SetAnimationTrack(SKINMODEL *skinModel, UINT anim) {
  LPD3DXANIMATIONSET animSet;

  skinModel->animCtrl->GetAnimationSet(anim, &animSet);
  skinModel->animCtrl->SetTrackAnimationSet(0, animSet);
  skinModel->animCtrl->SetTrackPosition(0, 0);
  skinModel->animCtrl->ResetTime();
}

ID3DXMesh * DirectXApplication::SkinModelMesh(SKINMODEL *skinModel) {
  ID3DXMesh *pMesh; // Secondary mesh container

  skinModel->mesh->CloneMeshFVF(0, skinModel->mesh->GetFVF(), d3ddev, &pMesh);

  // copy information from skin mesh to the secondary mesh and update it
  void *SrcPtr, *DestPtr;
  skinModel->mesh->LockVertexBuffer(D3DLOCK_READONLY, (void **)&SrcPtr);
  pMesh->LockVertexBuffer(0, (void **)&DestPtr);
  skinModel->skinInfo->UpdateSkinnedMesh(skinModel->skinMatrix,
                                         NULL,
                                         SrcPtr,
                                         DestPtr);
  skinModel->mesh->UnlockVertexBuffer();
  pMesh->UnlockVertexBuffer();
  return pMesh;
}

bool DirectXApplication::CollidedSkinModels(SKINMODEL *firstSkinModel,
                                            D3DXMATRIX firstMatrix,
                                            SKINMODEL *secondSkinModel,
                                            D3DXMATRIX secondMatrix)
{
  MODEL *firstModel = (MODEL *)malloc(sizeof(MODEL));

  firstModel->mesh = SkinModelMesh(firstSkinModel);

  MODEL *secondModel = (MODEL *)malloc(sizeof(MODEL));
  secondModel->mesh = SkinModelMesh(secondSkinModel);

  bool result;

  if(Collided(firstModel, firstMatrix, secondModel,
              secondMatrix) == true) result = true;
  else    result = false;

  firstModel->mesh->Release();
  delete firstModel;

  secondModel->mesh->Release();
  delete secondModel;

  return result;
}

void DirectXApplication::Translate(D3DXMATRIX& mat,
                                   D3DXVECTOR3 pos,
                                   D3DXVECTOR3 rot,
                                   D3DXVECTOR3 scale)
{
  D3DXMATRIX S, R, T;

  D3DXMatrixScaling(&S, scale.x, scale.y, scale.z);
  D3DXMatrixRotationYawPitchRoll(&R, rot.y, rot.x, rot.z);
  D3DXMatrixTranslation(&T, pos.x, pos.y, pos.z);
  mat = S * R * T;
}

D3DXVECTOR3 DirectXApplication::TranslateRot(D3DXVECTOR3 rot) {
  const D3DXVECTOR3 idir(0.0f, 0.0f, -1.0f);
  D3DXVECTOR3 vdir;
  D3DXMATRIX  R;

  D3DXMatrixRotationYawPitchRoll(&R, rot.y, rot.x, rot.z);
  D3DXVec3TransformCoord(&vdir, &idir, &R);
  return vdir;
}

void DirectXApplication::DoTranslate(D3DXVECTOR3 pos,
                                     D3DXVECTOR3 rot,
                                     D3DXVECTOR3 scale) {
  D3DXMATRIX mat;

  Translate(mat, pos, rot, scale);
  d3ddev->SetTransform(D3DTS_WORLD, &mat);
}

VectorPair DirectXApplication::FindModelDimensions(MODEL *model)
{
  VectorPair bounds;
  void *pVertices = NULL;

  model->mesh->LockVertexBuffer(D3DLOCK_READONLY,
                                (LPVOID *)&pVertices);
  D3DXComputeBoundingBox((D3DXVECTOR3 *)pVertices,
                         model->mesh->GetNumVertices(),
                         D3DXGetFVFVertexSize(model->mesh->GetFVF()),
                         &bounds.first, &bounds.second);
  model->mesh->UnlockVertexBuffer();

  return bounds;
}

float DirectXApplication::FindSkinModelHeight(SKINMODEL *skinModel)
{
  void *pVertices = NULL;
  D3DXVECTOR3 minBounds, maxBounds;

  skinModel->mesh->LockVertexBuffer(D3DLOCK_READONLY,
                                    (LPVOID *)&pVertices);
  D3DXComputeBoundingBox((D3DXVECTOR3 *)pVertices,
                         skinModel->mesh->GetNumVertices(),
                         D3DXGetFVFVertexSize(skinModel->mesh->GetFVF()),
                         &minBounds, &maxBounds);
  skinModel->mesh->UnlockVertexBuffer();

  return maxBounds.y - minBounds.y;
}
