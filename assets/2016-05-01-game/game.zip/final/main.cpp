#include "Game.h"
#include <time.h>

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR     lpCmdLine,
                   int       nCmdShow) {
  Game game(hInstance, nCmdShow);

  if(game.Init()) return 0;

  while(!game.Run());
  return game.End();
}
