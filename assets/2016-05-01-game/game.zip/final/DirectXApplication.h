#pragma once

#include "WindowsApplication.h"

// header files
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <string>
#include <dinput.h>
#include <fstream>
#include <utility>
#include "DirectSound.h"
#include "AllocMeshHierarchy.h"

#pragma comment(lib,"d3d9.lib")
#pragma comment(lib,"d3dx9.lib")
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"dsound.lib")
#pragma comment(lib,"dxerr.lib")
#pragma comment(lib,"winmm.lib")

// vertex and quad definitions
#define D3DFVF_MYVERTEX (D3DFVF_XYZ | D3DFVF_TEX1)
#define WHITE D3DXCOLOR(1.0, 1.0, 1.0, 1.0)
#define BLACK D3DXCOLOR(0.0, 0.0, 0.0, 0.0)

// structs
struct VERTEX
{
  float x, y, z;
  float tu, tv;
};

struct QUAD
{
  VERTEX                  vertices[4];
  LPDIRECT3DVERTEXBUFFER9 buffer;
  LPDIRECT3DTEXTURE9      texture;
};

struct MODEL
{
  LPD3DXMESH          mesh;
  D3DMATERIAL9       *materials;
  LPDIRECT3DTEXTURE9 *textures;
  DWORD               material_count;
};

struct SKINMODEL : MODEL
{
  LPD3DXSKININFO skinInfo;
  D3DXFRAME     *root;
  long numBones;
  D3DXMATRIX  *skinMatrix;
  D3DXMATRIX **frameToRootMatrix;
  ID3DXAnimationController *animCtrl;
};

typedef std::pair < D3DXVECTOR3, D3DXVECTOR3 > VectorPair;

class DirectXApplication: public WindowsApplication {
public:

  DirectXApplication(HINSTANCE hInstance,
                     int nCmdShow,
                     std::string title,
                     int width,
                     int height);

  int  Init();
  int  StartRun();
  int  EndRun();
  int  Run();
  int  End();

  // Direct3D functions
  bool Direct3D_Init(HWND hwnd,
                     int  width,
                     int  height,
                     bool fullscreen);
  void               Direct3D_Shutdown();

  LPDIRECT3DSURFACE9 LoadSurface(std::string filename);
  void               DrawSurface(LPDIRECT3DSURFACE9 dest,
                                 float              x,
                                 float              y,
                                 LPDIRECT3DSURFACE9 source);
  LPDIRECT3DTEXTURE9 LoadTexture(char    *filename,
                                 D3DCOLOR transcolor);
  void               Sprite_Draw_Frame(LPDIRECT3DTEXTURE9 texture,
                                       int                destx,
                                       int                desty,
                                       int                framenum,
                                       int                framew,
                                       int                frameh,
                                       int                columns);
  void Sprite_Animate(int& frame,
                      int  startframe,
                      int  endframe,
                      int  direction,
                      int& starttime,
                      int  delay);

  // DirectInput objects, devices, and states
  LPDIRECTINPUT8 dinput;
  LPDIRECTINPUTDEVICE8 dimouse;
  LPDIRECTINPUTDEVICE8 dikeyboard;
  DIMOUSESTATE mouse_state;
  char keys[256];

  // DirectInput functions
  bool    DirectInput_Init(HWND);
  void    DirectInput_Update();
  void    DirectInput_Shutdown();
  int     Key_Down(int);
  int     Mouse_Button(int);
  int     Mouse_X();
  int     Mouse_Y();

  // DirectSound functions
  bool    DirectSound_Init(HWND hwnd);
  void    DirectSound_Shutdown();
  CSound* LoadSound(std::string filename);
  void    PlaySound(CSound *sound);
  void    LoopSound(CSound *sound);
  void    StopSound(CSound *sound);

  void    SetCamera(float x,
                    float y,
                    float z,
                    float lookx,
                    float looky,
                    float lookz);
  void SetPerspective(float fieldOfView,
                      float aspectRatio,
                      float nearRange,
                      float farRange);
  VERTEX CreateVertex(float x,
                      float y,
                      float z,
                      float tu,
                      float tv);
  QUAD * CreateQuad(char *textureFilename);
  void   DeleteQuad(QUAD *quad);
  void   DrawQuad(QUAD *quad);

  MODEL* LoadModel(std::string filename);
  void   DrawModel(MODEL *model);
  void   DeleteModel(MODEL *model);
  bool   Collided(MODEL     *firstModel,
                  D3DXMATRIX firstMatrix,
                  MODEL     *secondModel,
                  D3DXMATRIX secondMatrix);

  SKINMODEL* LoadSkinModel(std::string filename);
  void       UpdateSkinModel(SKINMODEL *skinModel,
                             float      deltaTime);
  void       DrawSkinModel(SKINMODEL *skinModel);
  void       DeleteSkinModel(SKINMODEL *skinModel);
  bool       CollidedSkinModel(SKINMODEL *skinModel,
                               D3DXMATRIX firstMatrix,
                               MODEL     *secondModel,
                               D3DXMATRIX secondMatrix);
  bool CheckAnimationCollision(SKINMODEL *skinModel,
                               D3DXMATRIX firstMatrix,
                               float      animationSpeed,
                               MODEL     *secondModel,
                               D3DXMATRIX secondMatrix);

  void CalculateRay(int          x,
                    int          y,
                    D3DXVECTOR3& rayOrigin,
                    D3DXVECTOR3& rayDirection);
  bool CollidedModelRay(MODEL      *model,
                        D3DXMATRIX  transform,
                        D3DXVECTOR3 rayOrigin,
                        D3DXVECTOR3 rayDirection);

  void Translate(D3DXMATRIX& mat,
                 D3DXVECTOR3 pos = D3DXVECTOR3 { 0.0f, 0.0f, 0.0f },
                 D3DXVECTOR3 rot = D3DXVECTOR3 { 0.0f, 0.0f, 0.0f },
                 D3DXVECTOR3 scale = D3DXVECTOR3 { 1.0f, 1.0f, 1.0f });
  D3DXVECTOR3 TranslateRot(D3DXVECTOR3 rot);
  void        DoTranslate(
    D3DXVECTOR3 pos = D3DXVECTOR3 { 0.0f, 0.0f, 0.0f },
    D3DXVECTOR3 rot = D3DXVECTOR3 { 0.0f, 0.0f, 0.0f },
    D3DXVECTOR3 scale = D3DXVECTOR3 { 1.0f, 1.0f, 1.0f });
  D3DXFRAME* FindFrameWithName(D3DXFRAME  *frame,
                               std::string name);
  void       SetAnimationTrack(SKINMODEL *skinModel,
                               UINT       anim);
  ID3DXMesh* SkinModelMesh(SKINMODEL *skinModel);
  bool       CollidedSkinModels(SKINMODEL *firstSkinModel,
                                D3DXMATRIX firstMatrix,
                                SKINMODEL *secondSkinModel,
                                D3DXMATRIX secondMatrix);
  VectorPair FindModelDimensions(MODEL *model);
  float      FindSkinModelHeight(SKINMODEL *skinModel);


  float aspect;

  LPDIRECT3D9 d3d;
  LPDIRECT3DDEVICE9  d3ddev;
  LPDIRECT3DSURFACE9 backbuffer;
  LPD3DXSPRITE sprite_obj;

  // primary DirectSound object
  CSoundManager *dsound;
};
