#include "Player.h"
#include "DirectXApplication.h"
#include "Game.h"

static inline float random_float() {
  // http://stackoverflow.com/questions/686353/c-random-float-number-generation
  return static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
}

static inline float random_range(float start, float end) {
  return (random_float() * (end - start)) + start;
}

Player::Player(Game *app, int pid) :
  app(app), pid(pid), model(0), sword(0) {
  playerState = RESTING;
  type        = PLAYER;
}

Player::~Player() {}

int Player::Init() {
  if(!model) model = app->LoadSkinModel("rcs/character.x");

  if(!sword) sword = app->LoadSkinModel("rcs/sword.x");
  const VectorPair dim = app->Dimensions();
  pos = D3DXVECTOR3 {
    random_range(dim.first.x, dim.second.x / 2),
    random_range(dim.first.y, dim.second.y),
    random_range(dim.first.z, dim.second.z / 2)
  };
  dir = D3DXVECTOR3 { 0, 0, 0 };
  SetState(RESTING);

  return 0;
}

int Player::StartRun() {
  static const float anim_duration = 1.75f,
                     anim_speed    = 0.05f;

  if(model->animCtrl->GetTime() > anim_duration) {
    if(!stateQueue.empty()) {
      playerState = stateQueue.front();
      stateQueue.pop_front();
      app->SetAnimationTrack(model, playerState);
      app->SetAnimationTrack(sword, playerState);
    }
    else if((playerState != DEFAULT) &&
            (playerState != RESTING) &&
            (playerState != RUNNING) &&
            (playerState != WALKING)) SetState(RESTING);
  }

  app->UpdateSkinModel(model, anim_speed);
  app->UpdateSkinModel(sword, anim_speed);

  int err = app->ProcessCollisions(this);

  if(err) return err;

  return err;
}

int Player::Run() {
  app->DoTranslate();
  app->DoTranslate(pos, D3DXVECTOR3 { dir.x, dir.y + D3DX_PI / 2, dir.z });
  app->DrawSkinModel(model);

  app->DoTranslate();
  app->DoTranslate(pos, D3DXVECTOR3 { dir.x, dir.y + D3DX_PI / 2, dir.z });
  app->DrawSkinModel(sword);

  return 0;
}

int Player::End() {
  app->DeleteModel(model);
  app->DeleteModel(sword);
  return 0;
}

char * Player::GetData(int& size) {
  size = sizeof(playerdata);
  return reinterpret_cast<char *>(new playerdata { pid, pos, dir.y, playerState,
                                                   yvel,
                                                   model->animCtrl->GetTime() });
}

int Player::SetData(char *data, int size) {
  if(size < sizeof(playerdata)) return 1;

  last_pos = pos;
  playerdata *pd = reinterpret_cast<playerdata *>(data);
  pos         = pd->pos;
  dir.y       = pd->dir;
  playerState = pd->state;
  yvel        = pd->yvel;
  model->animCtrl->AdvanceTime(model->animCtrl->GetTime() - pd->animTime, 0);
  sword->animCtrl->AdvanceTime(model->animCtrl->GetTime() - pd->animTime, 0);
  return 0;
}

int Player::IsDead() {
  return playerState == DEFAULT;
}

void Player::SetState(State state, bool queue) {
  if(queue) {
    if(stateQueue.empty() ||
       (stateQueue.back() != state)) stateQueue.emplace_back(state);
  }
  else {
    stateQueue.clear();
    playerState = state;
    app->SetAnimationTrack(model, state);
    app->SetAnimationTrack(sword, state);
  }
}
