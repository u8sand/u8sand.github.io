#pragma once

#include "DirectXApplication.h"

#include <deque>
#include <utility>

class Player;
class PlayerOne;
class NPC;
class NetworkManager;

typedef std::deque < Player * > Players;

class Game: public DirectXApplication {
  friend NetworkManager;
  friend Player;

public:

  Game(HINSTANCE hInstance, int nCmdShow);

  int        Init();
  int        Run();
  int        End();
  int        Exec();

  Player   * NewPlayer(int pid);
  void       KillPlayer(Player *player);

  D3DXVECTOR3 wall_pos(D3DXVECTOR3 pos, D3DXVECTOR3 dir);
  int        ProcessCollisions(Player *player);

  VectorPair Dimensions() {
    return mapDimensions;
  }

  const float gravity = 0.15f;

  PlayerOne *player;
  NPC *npc;
protected:

  NetworkManager *network;
  Players    players;
  MODEL     *mapModel;
  VectorPair mapDimensions;
};
