#pragma once

#include <unordered_map>

#include "SocketAddr.h"

#define BROADCAST INADDR_BROADCAST

// #define BROADCAST 0xc0a801ff // 192.168.1.255

class Game;
class Player;

class NetworkManager {
public:

  NetworkManager(Game * game);
  ~NetworkManager();

  int Init();
  int Run();
  int End();

private:

  SOCKET sock;
  SocketAddr addr, broadcast, myaddr;

  Game *game;

  typedef std::unordered_map < int, Player * > PeerMap;
  PeerMap peers;
};
