#pragma once

#include "Player.h"

class NPC: public Player {
public:

  NPC(Game * app);
  ~NPC();

  int StartRun();

protected:

  Game *app;
};
