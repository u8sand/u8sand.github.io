#include "WindowsApplication.h"

LRESULT WINAPI WinProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
  case WM_DESTROY:
    PostQuitMessage(0);
    return 0;
  }
  return DefWindowProc(hWnd, msg, wParam, lParam);
}

WindowsApplication::WindowsApplication(HINSTANCE   hInstance,
                                       int         nCmdShow,
                                       std::string title,
                                       int         width,
                                       int         height) :
  title(title), width(width), height(height) {
  WNDCLASSEX wc;

  wc.cbSize        = sizeof(WNDCLASSEX);
  wc.style         = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc   = (WNDPROC)WinProc;
  wc.cbClsExtra    = 0;
  wc.cbWndExtra    = 0;
  wc.hInstance     = hInstance;
  wc.hIcon         = NULL;
  wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
  wc.lpszMenuName  = NULL;
  wc.lpszClassName = title.c_str();
  wc.hIconSm       = NULL;
  RegisterClassEx(&wc);

  // create a new window
  hwnd = CreateWindow(title.c_str(), title.c_str(),
                      WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                      width, height, NULL, NULL, hInstance,
                      NULL);

  if(hwnd != 0) {
    // display the window
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
  }
}

int WindowsApplication::Init() {
  if(!hwnd) return 1;

  return 0;
}

int WindowsApplication::Run() {
  if(PeekMessage(&message, NULL, 0, 0, PM_REMOVE))
  {
    if(message.message == WM_QUIT) return 1;

    TranslateMessage(&message);
    DispatchMessage(&message);
  }
  return 0;
}

int WindowsApplication::End() {
  return 0;
}
