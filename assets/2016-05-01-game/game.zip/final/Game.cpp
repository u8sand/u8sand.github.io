#include "Game.h"
#include "Player.h"
#include "PlayerOne.h"
#include "NPC.h"
#include "NetworkManager.h"

Game::Game(HINSTANCE hInstance, int nCmdShow) :
  DirectXApplication(hInstance, nCmdShow, "Game", 1980, 1200) {
  network = new NetworkManager(this);
  player  = new PlayerOne(this);
  players.emplace_back(dynamic_cast<Player *>(player));
}

int Game::Init() {
  int err = DirectXApplication::Init();

  if(err) return err;

  mapModel      = LoadModel("rcs/dojo.x");
  mapDimensions = FindModelDimensions(mapModel);
  player->Init();
  network->Init();
  return 0;
}

int Game::Run() {
  network->Run();

  for(Players::iterator p = players.begin();
      p != players.end();
      p++) {
    if((*p)->type == PLAYER_ONE) reinterpret_cast<PlayerOne *>(*p)->StartRun();
    else if((*p)->type == PLAYER_NPC) reinterpret_cast<NPC *>(*p)->StartRun();
    else (*p)->StartRun();

    if((*p)->IsDead()) (*p)->Init(); // TODO: remove player
  }

  if(DirectXApplication::StartRun()) {
    DoTranslate();
    DrawModel(mapModel);

    for(Players::iterator p = players.begin();
        p != players.end();
        p++) (*p)->Run();
    return DirectXApplication::EndRun();
  }
  return DirectXApplication::Run();
}

int Game::End() {
  for(Players::iterator p = players.begin();
      p != players.end();
      p++) (*p)->End();
  DeleteModel(mapModel);
  network->End();
  return DirectXApplication::End();
}

Player * Game::NewPlayer(int pid) {
  Player *player = new Player(this, pid);

  player->Init();
  players.emplace_back(player);
  return player;
}

void Game::KillPlayer(Player *player) {
  player->SetState(DEFAULT);
}

static inline float limit_to(float x, float min_x, float max_x) {
  if(x < min_x) return min_x;

  if(x > max_x) return max_x;

  return x;
}

static inline bool equal_to(float a, float b, float eps) {
  float d = abs(a) - abs(b);

  return (d < eps) && (d > -eps);
}

D3DXVECTOR3 Game::wall_pos(D3DXVECTOR3 pos, D3DXVECTOR3 dir) {
  BOOL  hit;
  DWORD face, count;
  FLOAT pU, pV, dist;
  LPD3DXBUFFER allHits;

  // Wall/Object Collision
  D3DXIntersect(mapModel->mesh,
                &pos, &dir, &hit, &face,
                &pU, &pV, &dist, &allHits,
                &count);

  if(hit) {
    D3DXINTERSECTINFO *hits =
      reinterpret_cast<D3DXINTERSECTINFO *>(allHits->GetBufferPointer());

    for(int i = 0; i < count; i++) {
      if(hits[i].FaceIndex == face) {
        dist = hits[i].Dist;
        break;
      }
    }
    return pos + dist * dir;
  }
  else    return D3DXVECTOR3();
}

int Game::ProcessCollisions(Player *player) {
  static const float floor_thickness = 1.0f,
                     wall_thickness  = 1.5f,
                     map_death       = -5.0f,
                     backoff         = 0.1f;


  // Mesh Dojo Collision Handling
  // Drawing a line from the player position downwards and in the direction
  //  we're moving, what is the first face on the dojo that we hit?
  D3DXVECTOR3 down = { 0.0f, -1.0f, 0.0f },
              dir  = player->last_pos - player->pos,
              ndir, nxdir, nzdir, wall;

  D3DXVec3Normalize(&ndir, &dir);
  nxdir = { ndir.x, 0.0f, 0.0f };
  nzdir = { 0.0f, 0.0f, ndir.z };

  if(player->last_pos != player->pos) {
    player->pos.x = limit_to(player->pos.x,
                             mapDimensions.first.x + wall_thickness,
                             mapDimensions.second.x - wall_thickness);
    player->pos.z = limit_to(player->pos.z,
                             mapDimensions.first.z + wall_thickness,
                             mapDimensions.second.z - wall_thickness);

    /*wall = wall_pos(player->last_pos, nxdir);
       if (wall != D3DXVECTOR3()) {
            if (ndir.x > 0 && player->pos.x > wall.x)
                    player->pos.x = wall.x;
            else if (ndir.x < 0 && player->pos.x < wall.x)
                    player->pos.x = wall.x;
       }
       wall = wall_pos(player->last_pos, nzdir);
       if (wall != D3DXVECTOR3()) {
            if (ndir.z > 0 && player->pos.z > wall.z)
                    player->pos.z = wall.z;
            else if (ndir.z < 0 && player->pos.z < wall.z)
                    player->pos.z = wall.z;
       }*/
  }

  // Gravity/ground collision

  player->last_pos.y += floor_thickness;
  float next_y      = player->pos.y + player->yvel;
  D3DXVECTOR3 floor = wall_pos(player->last_pos, down);

  if((floor == D3DXVECTOR3()) || (next_y > floor.y)) {
    player->yvel -= gravity;

    if(next_y < map_death) {
      KillPlayer(player);
      return 0;
    }
  }
  else {
    next_y       = floor.y;
    player->yvel = 0;
  }

  player->pos.y = next_y;


  // Player collision

  if(players.front() != players.back()) {
    static MODEL playerModel, playerSword, p2Sword;
    static D3DXMATRIX playerMatrix, p2Matrix;

    playerModel.mesh = SkinModelMesh(player->model);
    playerSword.mesh = SkinModelMesh(player->sword);

    Translate(playerMatrix, player->pos, player->dir);

    for(Players::iterator p = players.begin();
        p != players.end();
        p++) {
      if((*p) == player) continue;
      Translate(p2Matrix, (*p)->pos, (*p)->dir);
      p2Sword.mesh = SkinModelMesh((*p)->sword);

      if(Collided(&playerModel, playerMatrix, &p2Sword, p2Matrix)) {
        if(CollidedSkinModel((*p)->model, p2Matrix, &playerSword, playerMatrix)) {
          if(Collided(&playerSword, playerMatrix, &p2Sword, p2Matrix)) {
            (*p)->pos   -= TranslateRot((*p)->dir) * backoff;
            player->pos -= TranslateRot(player->dir) * backoff;
          }
          else {
            KillPlayer((*p));
            KillPlayer(player);
          }
        }
        else KillPlayer(player);
      }
      else if(CollidedSkinModel((*p)->model, p2Matrix, &playerSword,
                                playerMatrix)) {
        if(Collided(&playerSword, playerMatrix, &p2Sword, p2Matrix)) {
          (*p)->pos   -= TranslateRot((*p)->dir) * backoff;
          player->pos -= TranslateRot(player->dir) * backoff;
        }
        else KillPlayer((*p));
      }
      p2Sword.mesh->Release();
    }
    playerModel.mesh->Release();
    playerSword.mesh->Release();
  }

  return 0;
}
