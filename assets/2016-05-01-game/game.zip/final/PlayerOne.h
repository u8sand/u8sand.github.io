#pragma once

#include "Player.h"

class PlayerOne: public Player {
public:

  PlayerOne(Game * app);
  ~PlayerOne();

  int Init();
  int StartRun();
};
