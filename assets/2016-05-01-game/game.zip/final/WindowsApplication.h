#pragma once

#include <windows.h>
#include <string>

class WindowsApplication {
public:

  WindowsApplication(HINSTANCE hInstance,
                     int       nCmdShow,
                     std::string title,
                     int width,
                     int height);

  int Init();
  int Run();
  int End();

  int Exec();

protected:

  HWND hwnd;
  MSG  message;
  std::string title;
  int width, height;
};
