#include "NPC.h"
#include "DirectXApplication.h"
#include "PlayerOne.h"
#include "Game.h"
#include <time.h>

NPC::NPC(Game *app) :
  Player(app, 0) {
  this->app = app; // not sure why it doesn't get set
  srand(time(0));
  pid  = rand();
  type = PLAYER_NPC;
}

NPC::~NPC() {}

static float dist(D3DXVECTOR3 a, D3DXVECTOR3 b) {
  return sqrt(pow(b.x - a.x, 2) + pow(b.y - a.y, 2) + pow(b.z - a.z, 2));
}

int NPC::StartRun() {
  if(!app->player) return Player::StartRun();

  D3DXVECTOR3 undir = app->player->pos - pos;
  undir.y = 0;
  D3DXVec3Normalize(&dir, &undir); // normalize direction vector
  dir.y = atan(-dir.z / dir.x);
  dir.x = dir.z = 0;

  static const float rot_speed     = 0.1f,
                     jmp_vel       = 1.5f,
                     run_speed     = 0.4f,
                     walk_speed    = 0.1f,
                     attack_thresh = 0.1f;

  static const time_t timeout = 1000;
  static time_t tick;
  time_t tock = GetTickCount();

  if(tock - tick > timeout) {
    last_pos = pos;

    if(dist(pos, app->player->pos) < attack_thresh) {
      switch(rand() % 4) {
      case 0:
        SetState(SLICE_DOWN_UP, true);
        break;

      case 1:
        SetState(SLICE_UP_DOWN, true);
        break;

      case 2:
        SetState(SLICE_LEFT_RIGHT, true);
        break;

      case 3:
        SetState(SLICE_RIGHT_LEFT, true);
        break;
      }
    }
    else {
      int r = rand() % 100;

      if(r < 10) SetState(WALKING);
      else if(r < 90) SetState(RUNNING);
      else {
        if(yvel == 0.0f) yvel = jmp_vel;
      }
    }
    tick = tock;
  }

  if(playerState == RUNNING) pos = pos + dir * walk_speed;
  else if(playerState == WALKING) pos = pos + dir * walk_speed;
  return Player::StartRun();
}
