#pragma once

#include "DirectXApplication.h"

#include <deque>

enum State {
  DEFAULT,          // Default_Action
  WALKING,          // walking_2_6mps
  SLICE_UP_DOWN,    // slice_updown
  SLICE_UNSHEATH,   // slice_unsheath
  SLICE_RIGHT_LEFT, // slice_rightleft
  SLICE_LEFT_RIGHT, // slice_leftright
  SLICE_DOWN_UP,    // slice_downup
  SHEATHING,        // sheathing
  RUNNING,          // running_8mps
  RESTING,          // resting
  UNSHEATHING       // unsheathing
};

enum PlayerType {
  PLAYER,
  PLAYER_ONE,
  PLAYER_NPC
};

struct playerdata {
  int         pid;
  D3DXVECTOR3 pos;
  float       dir;
  State       state;
  float       yvel;
  double      animTime;
};

class Game;

class Player {
  friend Game;

public:

  Player(Game * app, int pid);
  ~Player();

  int   Init();
  int   StartRun();
  int   Run();
  int   End();

  char* GetData(int& size);  // return update data
  int   SetData(char *data,
                int   size); // update from data
  int   IsDead();
  int   PID() {
    return pid;
  }

  void SetState(State state,
                bool  queue = false);

  PlayerType type;


  Game *app;
  int   pid;
  SKINMODEL  *model, *sword;
  D3DXVECTOR3 pos, dir, last_pos;
  float       yvel;
  State       playerState;
  std::deque < State > stateQueue;
};
